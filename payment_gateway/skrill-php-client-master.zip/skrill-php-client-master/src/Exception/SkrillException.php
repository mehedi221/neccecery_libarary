<?php

declare(strict_types=1);

namespace Skrill\Exception;

/**
 * Interface SkrillException.
 */
interface SkrillException
{
}
