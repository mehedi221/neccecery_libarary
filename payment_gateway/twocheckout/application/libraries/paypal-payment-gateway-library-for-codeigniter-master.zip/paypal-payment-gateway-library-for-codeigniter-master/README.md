# paypal-payment-gateway-library-for-codeigniter

# How to integrate paypal payment gateway in codeigniter? So you can visit the below link

https://www.tutsmake.com/paypal-payment-gateway-integration-in-codeigniter/
